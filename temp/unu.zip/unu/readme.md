# unu Challenge


## Latex
Yay, I get to break out the LaTeX again. The document with the responses is in the `latex` directory. There is a compiled pdf includeded but instuctions for recompiling it is below.

### Installation 
The Tex compiler along with some packages are required for building the file. Examples for the requirements for Ubuntu and arch are given below. Otherwise you should be able to find the relevent pacakges on your own disterbution.

#### Ubuntu
```bash
sudo apt install texlive-full
```
#### Arch Linux
```bash
pacman -S texlive-most
```

### Build
There is a makefile for building the PDF. It uses `pdflatex` and outputs `challenge.pdf`. It might need to be built twice to allow the label and refrence library to be built.

```bash
make
```

## Spice


## Circuit

- Library Genreation
  - Fototprint
  - Cad model
  - Symbol
- Circuit design
- componet selection
- Layout
- Documentation

Line level is 0.77Vrms
5W on a 8 ohm load is 6.32Vrms
\frac{V^2}{R} = P   
18.28x gain -> 20db gain
5.6k to gnd
Mute jumper cut to mute

0.77V RMS line/heaphone input
Stero balacned input

Balanced Jack Sony standard
T    R    R    R    S
L+  L-  R+  R-  Gnd

Digikey is down, yay!

## Text Invert

Issues and notes. Only three valid end of sentence punctuation marks \texttt{.!?}. Errors with empty string or just punctuation. Removes extra spaces. Does not affect case. Removes end characters that do not fit `.?!` capture group.
 
Tests:
 
am i as happy as you are?
are you as happy as i am?
 
a.
a.
 
am        I sad?
sad I am?