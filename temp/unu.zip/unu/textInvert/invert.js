// sawaiz 2021-02
// run as 'node invet.js <arg>'
// ex 'node invert.js "am i as happy as you are?" 
// As a onleliner since JS lets you do dumb stuff strings easily.
console.log([
    process.argv[2].match(/(\w+(\w )*)/g)   // Get a array of words seperated by space
      .reverse()                            // Reverse the array
      .join(" "),                           // Join with space.
    process.argv[2].match(/[?!.]$/g)        // Capture punctuation if exists at end of line
].join(""));                                // Join with punctuation if it is not undefined

